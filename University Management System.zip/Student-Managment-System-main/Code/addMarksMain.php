<?php
require_once "connection.php";
session_start();

if (!(isset($_SESSION['username']) && isset($_SESSION['password']) && $_SESSION['user'] == "faculty")) {
    echo "Error: Unauthorized access";
    exit;
}

$id = $_POST["cid"];
$t = $_POST["type"];
$tm = $_POST["total_marks"];


$sql = "INSERT INTO Marks (cid, type, total_marks) VALUES ('{$id}', '{$t}', $tm)";

$result = mysqli_query($conn, $sql);

if ($result) {
   
    $mid = mysqli_insert_id($conn);

   
    $enrolled_students_sql = "SELECT sid FROM Enrollment WHERE cid = '{$id}'";
    $enrolled_students_result = mysqli_query($conn, $enrolled_students_sql);

    if ($enrolled_students_result) {
        while ($row = mysqli_fetch_assoc($enrolled_students_result)) {
            $sid = $row['sid'];

           
            $insert_student_attendance_sql = "INSERT INTO StudentMarks (mid, sid) VALUES ({$mid}, {$sid})";
            $insert_result = mysqli_query($conn, $insert_student_attendance_sql);

            if (!$insert_result) {
                echo "<div class='overflow-x-auto max-w-md mx-auto bg-white rounded-lg shadow-lg p-6'>
                    <h2 class='text-xl font-bold mb-4'>Failed to add attendance for student with ID: {$sid}</h2>
                    </div>";
            }
        }
        echo "<div class='max-w-md mx-auto bg-white rounded-lg shadow-lg p-6'>
            <h2 class='text-xl font-bold mb-4'>Marks and student records added successfully</h2>
            </div>";
    } else {
        echo "<div class='max-w-md mx-auto bg-white rounded-lg shadow-lg p-6'>
            <h2 class='text-xl font-bold mb-4'>Failed to retrieve enrolled students</h2>
            </div>";
    }
} else {
    echo "<div class='max-w-md mx-auto bg-white rounded-lg shadow-lg p-6'>
        <h2 class='text-xl font-bold mb-4'>Failed to add Marks</h2>
        </div>";
}

?>
